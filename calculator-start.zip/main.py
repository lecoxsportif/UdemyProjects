#Calculator
from art import logo

#Add
def add(n1, n2):
    return n1 + n2

#Subtract
def minus(n1, n2):
    return n1 - n2

#Multiply
def mult(n1, n2):
    return n1 * n2

#Divide
def div(n1, n2):
    return n1 / n2

operations = {
    "+" : add,
    "-" : minus,
    "*" : mult,
    "/" : div
}

def calculator():
    print(logo)

    num1 = float(input("What is the first number?: "))

    for symbol in operations:
        print(symbol)
    end_calc = False

    while not end_calc:
        operation_symbol = input("Pick an operation: ")
        num2 = float(input("What is the next number?: "))
        calc = operations[operation_symbol]
        answer = calc(num1, num2)

        print(f"{num1} {operation_symbol} {num2} = {answer}")


        if input(f"Type 'y' to continue calculating with {answer}', or 'n' to start a new calculation...\n") == "y":
            num1 = answer
        else:
            end_calc = True
            calculator()

calculator()